export class Product {
    id:number=0;
    productName:string = '';
    productId:number =0;
    price:number=0;
    description:string='';

}