import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Product } from 'src/app/models/product.model';
import { ProductServiceService } from 'src/app/service/product-service.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit {

  productForm: FormGroup;
  productDetails;
  productObj: Product = new Product();
  updateId: any;
  showAdd: boolean;
  constructor(private formBuilder: FormBuilder, private productService: ProductServiceService) { }

  ngOnInit(): void {
    this.productForm = this.formBuilder.group({
      productName: new FormControl(null, Validators.required),
      productId: new FormControl(null, Validators.required),
      price: new FormControl(null, Validators.required),
      description: new FormControl(null, Validators.required),

    })
    this.getProduct();
  }
  OnSubmit() {
    if (!this.productForm.valid) {
      this.productForm.markAllAsTouched();
    }
    else {
      this.AddProducts();
    }
  }
  AddProducts() {
    this.productObj.productName = this.productForm.value.productName;
    this.productObj.productId = this.productForm.value.productId;
    this.productObj.price = this.productForm.value.price;
    this.productObj.description = this.productForm.value.description;
    this.productService.AddProduct(this.productObj)
      .subscribe(res => {
        alert('added a product');
        let popup = document.getElementById('closePopup');
        popup?.click()
        this.productForm.reset();
        this.getProduct();
      },
        error => {
          alert("something went wrong")
        })
  }

  showAddButton() {
    this.productForm.reset();
    this.showAdd = true;
  }
  getProduct() {
    this.productService.getProducts().subscribe(res => {
      return this.productDetails = res;

    })
  }

  deleteProduct(product) {
    this.productService.deleteProduct(product.id).subscribe(res => {
      alert("product deleted");
      this.getProduct();
    })
  }

  editProduct(product) {
    this.showAdd = false;
    this.productObj.id = product.id;
    this.productForm.controls['productName'].setValue(product.productName);
    this.productForm.controls['productId'].setValue(product.productId);
    this.productForm.controls['price'].setValue(product.price);
    this.productForm.controls['description'].setValue(product.description)
  }

  closeButton() {
    let ref = document.getElementById('exampleModal');
    ref?.click();
  }

  UpdateProduct() {
    this.productObj.productName = this.productForm.value.productName;
    this.productObj.productId = this.productForm.value.productId;
    this.productObj.price = this.productForm.value.price;
    this.productObj.description = this.productForm.value.description;

    this.productService.updateProduct(this.productObj, this.productObj.id).subscribe(res => {
      alert("updated data successfully");
      this.productForm.reset();
      this.getProduct();
    },
      error => {
        alert("something went wrong");
      })
  }
}
