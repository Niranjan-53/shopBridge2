import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
loginForm: FormGroup;

constructor(
  private readonly formBuilder: FormBuilder,){}
initialiseForm() {
  this.loginForm = this.formBuilder.group({
    emailId: [null, [Validators.required]],
    password:[null,[Validators.required]]
  });
}
  title = 'ShopBridge';
}
